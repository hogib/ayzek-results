# ayzek: the 2025-04-23 Marmara Mw 6.2 and the hour after it, KO stations

Eight KOERI stations, 2025-04-23 09:00 to 10:45 UTC, 23 to 65 km from the
epicentre. The span starts 49 minutes before the mainshock on purpose: the
magnitude regressor normalises by each station's noise baseline, which is built
online from quiet windows, and a dataset that starts minutes before the event
reads about 0.6 magnitude units low on it.

    ./ayzek --speed 0 --catalog marmara_ko.csv *.mseed

Expect the **Mw 6.2 declared 10.5 s after origin** (BOTS and SLVT), the Mw 5.9
eleven seconds after its own origin, and 28 of the 37 catalogue events in the
span detected, median alarm 11.5 s after origin.

The magnitudes show the system's main weakness: the Mw 6.2 reads M5.2 and the
Mw 5.9 reads M4.2. The regressor saturates for large events (see the release
notes); it is trained on 10 s windows with few examples above M5.5.

## Data source and citation

Waveforms: **Kandilli Observatory and Earthquake Research Institute (KOERI),
Boğaziçi University**, network KO, retrieved from the KOERI FDSN service.
KO is open data; cite it as

> Kandilli Observatory And Earthquake Research Institute (KOERI), Boğaziçi
> University (1971). *Kandilli Observatory And Earthquake Research Institute
> (KOERI)*. International Federation of Digital Seismograph Networks.
> https://doi.org/10.7914/SN/KO

The catalogue CSV is an excerpt of an AFAD (Disaster and Emergency Management
Presidency of Türkiye) catalogue export, https://deprem.afad.gov.tr/

`dataset.json` records the exact request: span, stations, service and
retrieval time. `tools/fetch_ko_data.py` rebuilds the set from the archive.
