# ayzek demo: the 2025-11-10 Sındırgı Mw 4.9, KO stations

Six KOERI stations, 2025-11-10 18:04 to 18:35 UTC, 72 to 117 km from the
epicentre. One miniSEED file per station, HH channels, 100 Hz.

Unpack beside the `ayzek` binary and the `models` directory, then:

    ./ayzek --speed 10 --from 2025-11-10T18:20:00 --catalog demo_ko.csv *.mseed

Expect the Mw 4.9 declared **18.0 s after origin** by KULA and SIMA. Over the
whole 30 minutes at full speed (drop `--speed 10 --from`), 8 of the 9
catalogue events are detected, 2 alarms have no catalogue event, the median
alarm comes 17.8 s after origin and the mean magnitude error is 0.35.

## Data source and citation

Waveforms: **Kandilli Observatory and Earthquake Research Institute (KOERI),
Boğaziçi University**, network KO, retrieved from the KOERI FDSN service.
KO is open data; cite it as

> Kandilli Observatory And Earthquake Research Institute (KOERI), Boğaziçi
> University (1971). *Kandilli Observatory And Earthquake Research Institute
> (KOERI)*. International Federation of Digital Seismograph Networks.
> https://doi.org/10.7914/SN/KO

The catalogue CSV is an excerpt of an AFAD (Disaster and Emergency Management
Presidency of Türkiye) catalogue export, https://deprem.afad.gov.tr/

`dataset.json` records the exact request: span, stations, service and
retrieval time. `tools/fetch_ko_data.py` rebuilds the set from the archive.
