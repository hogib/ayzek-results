# ayzek: a quiet window, for the false-alarm rate

Six KOERI stations, 2024-01-03 11:25 to 17:25 UTC. The AFAD catalogue holds
**no event within 250 km of any of these stations** for this span, so every
alarm is a false alarm.

    ./ayzek --speed 0 --no-magnitude --from 2024-01-03T11:35:00 \
        --catalog quiet_ko.csv *.mseed

The first ten minutes build each station's noise baseline without triggering.
Expect **1 alarm in 5.8 h**, 4.1 a day. The same command with
`--detector stalta` raises **25**, 103 a day: the detector's advantage over
the classical trigger is mostly here, not in detection rate.

## Data source and citation

Waveforms: **Kandilli Observatory and Earthquake Research Institute (KOERI),
Boğaziçi University**, network KO, retrieved from the KOERI FDSN service.
KO is open data; cite it as

> Kandilli Observatory And Earthquake Research Institute (KOERI), Boğaziçi
> University (1971). *Kandilli Observatory And Earthquake Research Institute
> (KOERI)*. International Federation of Digital Seismograph Networks.
> https://doi.org/10.7914/SN/KO

The catalogue CSV is an excerpt of an AFAD (Disaster and Emergency Management
Presidency of Türkiye) catalogue export, https://deprem.afad.gov.tr/

`dataset.json` records the exact request: span, stations, service and
retrieval time. `tools/fetch_ko_data.py` rebuilds the set from the archive.
