# Freeze checks, 2026-10-30 (pd-magnitude-window, worktree audit-fixes, fc00132)

- Dev regression (tools/regression_dev.py, 100 event + 20 quiet rows):
  build-dev 120/120 reproduced; static build-linux 120/120 reproduced.
- aarch64 (build-pi, qemu): 21/21 after 805a03e (test_network skips its
  network_subsets child process in cross builds).
- ASan+UBSan (build-asan, AYZEK_LIVE_SPEED=2): 24/24, no sanitizer report.
- TSan (build-tsan, AYZEK_LIVE_SPEED=2): 21/24. No race in ayzek.
  - bench_quick exit 66: races on bench/ayzek_bench.cpp globals (g_rng, g_sink),
    benchmark-only code predating SeedLink.
  - seedlink_live / seedlink_reconnect: the live runs are clean (nothing dropped,
    nothing out of order, archive complete); the *reference file replays* lost
    their tails ("flushing the last samples for 60 s with no progress"), because
    one TSan processor pass takes over 60 s. Same finding as the SeedLink review.
    The 60 s rule also applies at the end of a live run, so only hardware where
    a pass takes over 60 s is affected.
- SeisBench weights: 7 used files byte-identical here and on mousev.
